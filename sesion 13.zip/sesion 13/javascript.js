window.onscroll = function(){
  efectoHabilidades()  
};

function efectoHabilidades(){
    var skills = document.getElementById("skils");
    var distancia_skills = window.innerHeight - skills.getBoundingClientRect().top;
    if(distancia_skills >= 300){
        document.getElementById("html").classList.add("barra-progreso1");
        document.getElementById("css").classList.add("barra-progreso2");
        document.getElementById("js").classList.add("barra-progreso3");
        document.getElementById("bts").classList.add("barra-progreso4");
    }
}